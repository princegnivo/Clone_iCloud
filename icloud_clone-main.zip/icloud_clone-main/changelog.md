## [CHANGE LOG]

### Upcoming
- Handle login flow.
- Auto send OTP to victims iPhone.

#### April 14, 2025
- Responsive for smartphone (XS Screen).
- Add alert message.
- Handle AppleID, Password, 2FA OTP

#### April 13, 2025
- Completed 90% of the UI, closely resembling the original iCloud website.
- Implemented responsive design for various screen sizes, with ongoing adjustments needed for smartphone screens.

